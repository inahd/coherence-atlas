Yantra Scope 2D v2 — Accuracy Pass (Offline)

Open: yantra_scope2d_v2_accurate.html

What changed:
- Radii params were auto-fit to the uploaded yantra images by matching radial edge-profile peaks to each layer.
- Lotus petal counts were re-estimated (angular FFT near petal tips) and updated where stable.

Files:
- yantra_scope2d_v2_accurate.html : single-file app (data embedded)
- yantras_accurate.json           : updated param dataset
- accuracy_report.json            : per-yantra notes (petal updates)
